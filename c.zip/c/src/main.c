#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "livres.h"
#include "membres.h"

int main() {

    int choix;
    int check;

    while (1) {
        printf("\n********* Menu Principal *********\n");


        int taille_exclus = 0;
        int* current_exclus = verifier_date_limite_retour(&taille_exclus);

        printf("\n");
        printf("1. Livres\n");
        printf("2. Membres\n");
        printf("3. Quitter\n");
        printf("\nEntrez votre choix : ");

        check = scanf("%2d", &choix);

        if (check != 1) {
            printf("Saisie invalide. Veuillez saisir un nombre.\n");
            while (getchar() != '\n'); // Vider le flux d'entrée en vidant le tampon
        }
        else {
            if (choix < 1 || choix > 3) {
                printf("Choix invalide. Veuillez saisir un nombre entre 1 et 3.\n");
            }
            else {
                switch (choix) {
                    case 1:
                        menuLivres();
                        break;
                    case 2:
                        menuMembres(current_exclus);
                        break;
                    case 3:
                        return 0; // Quitter le programme
                }
            }
        }
    }

    return 0;
}

void menuLivres() {

    int choix = 0;
    // Boucle pour le sous-menu "Livres"
    while (choix != 6) {
        printf("\n********* Menu Livres *********\n");
        printf("1. Ajouter un livre\n");
        printf("2. Modifier un livre\n");
        printf("3. Supprimer un livre\n");
        printf("4. Afficher tous les livres\n");
        printf("5. Recherche de livre.s\n");
        printf("6. Retour au menu principal\n");
        printf("\nEntrez votre choix : ");
        scanf("%2d", &choix);

        int id;
        switch (choix) {
            case 1:
                // Appel de la fonction pour ajouter un livre
                ajouter_livre();
                break;
            case 2:
                // Appel de la fonction pour modifier un livre
                printf("%s", "ID du livre : ");
                scanf("%2d", &id);
                modifier_livre(id);
                break;
                
            case 3:
                // Appel de la fonction pour supprimer un livre
                printf("%s", "ID du livre : ");
                scanf("%2d", &id);
                supprimer_livre(id);
                break;
            
            case 4:
                // Appel de la fonction pour supprimer un livre
                afficher_livres();
                break;
            case 5:
                // Appel de la fonction pour recherche un livre
                rechercher_livre();
                break;
            case 6:
                // Retour au menu principal
                break;
            default:
                printf("Choix invalide. Veuillez réessayer.\n");
                break;
        }
    }
}

void menuMembres(int* current_exclus) {

    int choix = 0;
    // Boucle pour le sous-menu "Membres"
    while (choix != 12) {
        printf("\n********* Menu Membres *********\n");
        printf("1. Ajouter un membre\n");
        printf("2. Modifier un membre\n");
        printf("3. Supprimer un membre\n");
        printf("4. Afficher tous les membres\n");
        printf("5. Réserver un livre\n");
        printf("6. Emprunter un livre\n");
        printf("7. Retourner un livre\n");
        printf("8. Lister les emprunts actuels par membre\n");
        printf("9. Lister les emprunts actuels par oeuvre\n");
        printf("10. Lister l'historique d'emprunt par membre\n");
        printf("11. Lister l'historique d'emprunt par oeuvre\n");
        printf("12. Retour au menu principal\n");
        printf("\nEntrez votre choix : ");
        scanf("%2d", &choix);
        
        int id;
        switch (choix) {
            case 1:
                // Appel de la fonction pour ajouter un membre
                ajouter_membre();
                break;
            
            case 2:
                // Appel de la fonction pour modifier un membre
                printf("%s", "ID du membre : ");
                scanf("%2d", &id);
                modifier_membre(id);
                break;
            
            case 3:
                // Appel de la fonction pour supprimer un membre
                printf("%s", "ID du membre : ");
                scanf("%2d", &id);
                supprimer_membre(id);
                break;
            case 4:
                afficher_membres();
                break;
            case 5:
                afficher_livres();
                printf("Titre du livre : ");
                char titrev[MAX_TITRE];
                scanf(" %99[^\n]", titrev);
                printf("%s", "ID du membre qui réserve : ");
                scanf("%2d", &id);
                reserver_livre(titrev,id,current_exclus);
                break;
            case 6:
                afficher_livres();
                printf("Titre du livre : ");
                char titre[MAX_TITRE];
                scanf(" %99[^\n]", titre);
                printf("%s", "ID de l'emprunteur : ");
                scanf("%2d", &id);
                emprunter_livre(titre,id,current_exclus);
                break;
            case 7:
                afficher_livres();
                printf("Titre du livre : ");
                char titred[MAX_TITRE];
                scanf(" %99[^\n]", titred);
                printf("%s", "ID de l'emprunteur : ");
                scanf("%2d", &id);
                retour_livre(titred, id);
                break;
            case 8:
                printf("%s", "ID de l'emprunteur : ");
                scanf("%2d", &id);
                lister_emprunts(id);
                break;
            case 9:
                printf("Titre du livre : ");
                char titree[MAX_TITRE];
                scanf(" %99[^\n]", titree);
                lister_membres(titree);
                break;
            case 10:
                printf("%s", "ID de l'emprunteur : ");
                scanf("%2d", &id);
                afficher_historique_par_membre(id);
                break;
            case 11:
                printf("Titre du livre : ");
                char titreee[MAX_TITRE];
                scanf(" %99[^\n]", titreee);
                afficher_historique_par_oeuvre(titreee);
                break;
            case 12:
                // Retour au menu principal
                break;
            default:
                printf("Choix invalide. Veuillez réessayer.\n");
                break;
        }
        
    }
}