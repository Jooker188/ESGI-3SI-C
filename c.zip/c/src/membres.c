#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <unistd.h>
#include "membres.h"
#include "livres.h"
#include <time.h>
#include "json-c/json.h"

int generer_id_unique_membre() {
    FILE *file = fopen("../bin/membres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return -1;
    }

    int max_id = 0;
    char line[512];
    while (fgets(line, sizeof(line), file)) {
        json_object *json_obj = json_tokener_parse(line);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id > max_id) {
                    max_id = existing_id;
                }
            }
        }
        json_object_put(json_obj);
    }

    fclose(file);
    return max_id + 1;
}

void ajouter_membre() {
    Membre nouveauMembre;

    printf("Entrez les informations du nouveau membre :\n");
    
    printf("Prénom : ");
    scanf(" %99[^\n]", nouveauMembre.prenom);

    printf("Nom : ");
    scanf(" %99[^\n]", nouveauMembre.nom);

    printf("Date de naissance (xx-xx-xx) : ");
    scanf(" %11[^\n]", nouveauMembre.date_naissance);

    // Générer un identifiant unique pour le livre
    int nouveau_id = generer_id_unique_membre();
    nouveauMembre.id = nouveau_id;

    nouveauMembre.nb_livres_empruntes = 0;

    // Créer un objet JSON pour le livre
    json_object *data_membre = json_object_new_object();

    // Ajout des valeurs du livre à l'objet membre JSON
    json_object_object_add(data_membre, "id", json_object_new_int(nouveauMembre.id));
    json_object_object_add(data_membre, "prenom", json_object_new_string(nouveauMembre.prenom));
    json_object_object_add(data_membre, "nom", json_object_new_string(nouveauMembre.nom));
    json_object_object_add(data_membre, "date_naissance", json_object_new_string(nouveauMembre.date_naissance));
    json_object_object_add(data_membre, "livres_empruntes", json_object_new_array()); // Tableau vide
    json_object_object_add(data_membre, "nb_livres_empruntes", json_object_new_int(nouveauMembre.nb_livres_empruntes)); // Valeur initiale

    // Convertir l'objet JSON en chaîne de caractères
    const char *json_str = json_object_to_json_string_ext(data_membre, JSON_C_TO_STRING_PLAIN);
   
    // Sauvegarder le livre dans un fichier
    FILE *file = fopen("membres.json", "a");
    if (file) {
        fprintf(file, "%s\n", json_str);
        fclose(file);
        printf("Membre ajouté avec succès !\n");
    } else {
        printf("Erreur lors de l'ouverture du fichier.\n");
    }

    // Libérer la mémoire
    json_object_put(data_membre);

}

void modifier_membre(int membre_id) {
    FILE *file = fopen("../bin/membres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    FILE *temp_file = fopen("../bin/temp_membres.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(file);
        return;
    }

    char buffer[512];
    int membre_found = 0;

    while (fgets(buffer, sizeof(buffer), file)) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == membre_id) {
                    membre_found = 1;

                    Membre membre;
                    int choix;
                    printf("Que voulez-vous modifier ?\n");
                    printf("1. Prénom\n");
                    printf("2. Nom\n");
                    printf("3. Date de naissance\n");
                    printf("Votre choix : ");
                    scanf("%d", &choix);
                    getchar(); // Pour consommer le caractère de saut de ligne

                    switch (choix) {
                        case 1:
                            printf("Nouveau prénom : ");
                            scanf(" %99[^\n]", membre.prenom);
                            json_object_object_add(json_obj, "prenom", json_object_new_string(membre.prenom));
                            break;
                        case 2:
                            printf("Nouveau nom : ");
                            scanf(" %99[^\n]", membre.nom);
                            json_object_object_add(json_obj, "nom", json_object_new_string(membre.nom));
                            break;
                        case 3:
                            printf("Nouvelle date de naissance : ");
                            scanf(" %99[^\n]", membre.date_naissance);
                            json_object_object_add(json_obj, "date_naissance", json_object_new_string(membre.date_naissance));
                            break;
                        default:
                            printf("Choix invalide.\n");
                            json_object_put(json_obj);
                            continue;
                    }
                }
            }

            const char *json_str = json_object_to_json_string_ext(json_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_file, "%s\n", json_str);

            json_object_put(json_obj);
        } else {
            fprintf(temp_file, "%s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (membre_found) {
        if (rename("../bin/temp_membres.json", "../bin/membres.json") == 0) {
            printf("Le membre a été modifié avec succès.\n");
        } else {
            printf("Erreur lors de la modification du membre.\n");
        }
    } else {
        remove("../bin/temp_membres.json");
        printf("Le membre avec l'ID %d n'existe pas.\n", membre_id);
    }
}

void supprimer_membre(int membre_id) {
    FILE *file = fopen("../bin/membres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    FILE *temp_file = fopen("../bin/temp_membres.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(file);
        return;
    }

    char buffer[512];
    int membre_found = 0;

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == membre_id) {
                    membre_found = 1;
                    json_object_put(json_obj);
                    continue;
                }
            }
            const char *json_str = json_object_to_json_string_ext(json_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_file, "%s\n", json_str);
            json_object_put(json_obj);
        } else {
            fprintf(temp_file, "%s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (membre_found) {
        if (rename("../bin/temp_membres.json", "../bin/membres.json") == 0) {
            printf("Le membre a été supprimé avec succès.\n");
        } else {
            printf("Erreur lors de la modification du membre.\n");
        }
    } else {
        remove("../bin/temp_membres.json");
        printf("Le membre avec l'ID %d n'existe pas.\n", membre_id);
    }
}

void afficher_membres() {
    // Ouvrir le fichier livres.json en mode lecture
    FILE* file = fopen("membres.json", "r");
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier membres.json");
        return;
    }
    
    printf("%s", "\n------------ Membres de la bibliothèque ------------\n");
    
    char buffer[BUFSIZ];
    while (fgets(buffer, sizeof(buffer), file)) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj, *prenom_obj, *nom_obj, *date_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)
                && json_object_object_get_ex(json_obj, "prenom", &prenom_obj)
                && json_object_object_get_ex(json_obj, "nom", &nom_obj)
                && json_object_object_get_ex(json_obj, "date_naissance", &date_obj)) {
                printf("Id : %s\n", json_object_get_string(id_obj));    
                printf("Prénom : %s\n", json_object_get_string(prenom_obj));
                printf("Nom : %s\n", json_object_get_string(nom_obj));
                printf("Date de naissance : %s\n\n", json_object_get_string(date_obj));
            }
        }
    }

    // Fermer le fichier
    fclose(file);
}

void emprunter_livre(const char* livre_titre, int membre_id, int membres_exclus[]) {

    // Vérifier si le membre est exclu
    for (int i = 0; i < MAX_EXCLUS_SIZE; i++) {
        if (membres_exclus[i] == membre_id) {
            printf("Le membre %d est exclu et ne peut pas emprunter de livre.\n", membre_id);
            return;
        }
    }

    // Ouvrir le fichier "livres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    if (livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier livres.json.\n");
        return;
    }

    // Ouvrir le fichier temporaire
    FILE* temp_file = fopen("../bin/livres_temp.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(livres_file);
        return;
    }

    char buffer[512];
    int livre_trouve = 0;

    // Parcourir le fichier "livres.json" pour trouver le livre spécifique
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* titre = json_object_get_string(titre_obj);

                // Vérifier si le livre correspond aux critères de recherche
                if (strcmp(titre, livre_titre) == 0) {
                    json_object* statut_obj;
                    json_object* id_obj;
                    if (json_object_object_get_ex(livre_obj, "statut", &statut_obj)) {
                        const char* statut = json_object_get_string(statut_obj);
                        int id_reserveur;
                        if (json_object_object_get_ex(livre_obj, "id_reserveur", &id_obj)) {
                            id_reserveur = json_object_get_int(id_obj);

                            // Si le livre est disponible OU est réservé par le membre qui veut emprunter
                            if (strcmp(statut, "DISPONIBLE") == 0 || (strcmp(statut, "RESERVE") == 0 && membre_id == id_reserveur)) {
                                // Modifier le statut du livre
                                json_object_object_del(livre_obj, "statut");
                                json_object_object_add(livre_obj, "statut", json_object_new_string("EMPRUNTE"));

                                // Ajouter l'ID de l'emprunteur à l'historique_emprunteur
                                json_object* historique_emprunteur_array;
                                if (json_object_object_get_ex(livre_obj, "historique_emprunteur", &historique_emprunteur_array) &&
                                    json_object_get_type(historique_emprunteur_array) == json_type_array) {
                                    json_object_array_add(historique_emprunteur_array, json_object_new_int(membre_id));
                                } else {
                                    // Créer un nouveau tableau JSON contenant l'ID de l'emprunteur
                                    historique_emprunteur_array = json_object_new_array();
                                    json_object_array_add(historique_emprunteur_array, json_object_new_int(membre_id));
                                    json_object_object_add(livre_obj, "historique_emprunteur", historique_emprunteur_array);
                                }

                                // Ajouter l'attribut "date_limite_retour"
                                time_t now = time(NULL);
                                time_t date_limite_retour = now + 2 * 60;  // 2 minutes d'emprunt
                                json_object* date_limite_retour_obj = json_object_new_int64(date_limite_retour);
                                json_object_object_add(livre_obj, "date_limite_retour", date_limite_retour_obj);

                                livre_trouve = 1;
                            }
                        }
                    }
                }
            }

            // Convertir l'objet JSON en chaîne de caractères
            const char* livre_json_str = json_object_to_json_string_ext(livre_obj, JSON_C_TO_STRING_PLAIN);

            // Écrire la ligne dans le fichier temporaire
            fprintf(temp_file, "%s\n", livre_json_str);

            json_object_put(livre_obj);
        }
    }

    // Fermer les fichiers
    fclose(livres_file);
    fclose(temp_file);

    if (!livre_trouve) {
        printf("Le livre \"%s\" n'est pas disponible.\n", livre_titre);
        return;
    }

    // Renommer le fichier temporaire en "livres.json"
    int rename_result = rename("../bin/livres_temp.json", "../bin/livres.json");
    if (rename_result != 0) {
        printf("Erreur lors du renommage du fichier temporaire.\n");
        return;
    } else {
        update_emprunt_membre(livre_titre, membre_id);
        printf("Le livre %s a été emprunté avec succès.\n", livre_titre);
    }
}



void reserver_livre(const char* livre_titre, int membre_id, int membres_exclus[]){

    // Vérifier si le membre est exclu
    for (int i = 0; i < MAX_EXCLUS_SIZE; i++) {
        if (membres_exclus[i] == membre_id) {
            printf("Le membre %d est exclu et ne peut pas réserver de livre.\n", membre_id);
            return;
        }
    }
    // Ouvrir le fichier "livres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    if (livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier livres.json.\n");
        return;
    }

    // Ouvrir le fichier temporaire
    FILE* temp_file = fopen("../bin/livres_temp.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(livres_file);
        return;
    }

    char buffer[512];
    int livre_trouve = 0;

    // Parcourir le fichier "livres.json" pour trouver le livre spécifique
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* titre = json_object_get_string(titre_obj);

                // Vérifier si le livre correspond aux critères de recherche
                if (strcmp(titre, livre_titre) == 0) {
                        json_object* statut_obj;
                        if (json_object_object_get_ex(livre_obj, "statut", &statut_obj)) {
                            const char* statut = json_object_get_string(statut_obj);
                            if (strcmp(statut, "DISPONIBLE") == 0) {
                                // Modifier le statut du livre
                                json_object_object_del(livre_obj, "statut");
                                json_object_object_add(livre_obj, "statut", json_object_new_string("RESERVE"));
                                json_object_object_add(livre_obj, "id_reserveur", json_object_new_int(membre_id));

                                livre_trouve = 1;
                            }
                        }
                    
                }
            }

            // Convertir l'objet JSON en chaîne de caractères
            const char* livre_json_str = json_object_to_json_string_ext(livre_obj, JSON_C_TO_STRING_PLAIN);
            
            // Écrire la ligne dans le fichier temporaire
            fprintf(temp_file, "%s\n", livre_json_str);

            json_object_put(livre_obj);
        }
    }

    // Fermer les fichiers
    fclose(livres_file);
    fclose(temp_file);

    if (!livre_trouve) {
        printf("Le livre \"%s\" n'existe pas ou est déjà réservé/emprunté.\n", livre_titre);
        return;
    }

    // Renommer le fichier temporaire en "livres.json"
    int rename_result = rename("../bin/livres_temp.json", "../bin/livres.json");
    if (rename_result != 0) {
        printf("Erreur lors du renommage du fichier temporaire.\n");
        return;
    }
    else{
        printf("Le livre %s a été réservé avec succès.\n", livre_titre);
    }
}

void update_emprunt_membre(const char* livre_titre, int membre_id) {
    // Ouvrir le fichier "membres.json"
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier membres.json.\n");
        return;
    }

    // Créer un fichier temporaire pour stocker les modifications
    FILE* temp_file = fopen("../bin/membres_temp.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de la création du fichier temporaire.\n");
        fclose(membres_file);
        return;
    }

    char buffer[512];
    int found = 0;  // Indicateur pour vérifier si le membre a été trouvé

    // Parcourir le fichier "membres.json" pour trouver le membre spécifique
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* id_obj;
            if (json_object_object_get_ex(membre_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);

                if (existing_id == membre_id) {
                    // Mettre à jour le champ "livres_empruntes"
                    json_object* livres_empruntes_array;
                    if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_array) && json_object_get_type(livres_empruntes_array) == json_type_array) {
                        json_object_array_add(livres_empruntes_array, json_object_new_string(livre_titre));

                        // Mettre à jour le champ "historique_emprunt"
                        json_object* historique_emprunt_array;
                        if (!json_object_object_get_ex(membre_obj, "historique_emprunt", &historique_emprunt_array)) {
                            // Créer un nouveau tableau JSON vide pour "historique_emprunt"
                            historique_emprunt_array = json_object_new_array();
                            json_object_object_add(membre_obj, "historique_emprunt", historique_emprunt_array);
                        }
                        json_object_array_add(historique_emprunt_array, json_object_new_string(livre_titre));

                        // Mettre à jour le champ "nb_livres_empruntes"
                        json_object* nb_livres_empruntes_obj;
                        if (json_object_object_get_ex(membre_obj, "nb_livres_empruntes", &nb_livres_empruntes_obj)) {
                            int nb_livres_empruntes = json_object_get_int(nb_livres_empruntes_obj);
                            json_object_object_del(membre_obj, "nb_livres_empruntes");
                            json_object_object_add(membre_obj, "nb_livres_empruntes", json_object_new_int(nb_livres_empruntes + 1));
                        }

                        found = 1;  // Marquer le membre comme trouvé
                    }
                }

            }

            // Convertir l'objet JSON modifié en chaîne de caractères
            const char* membre_json_str = json_object_to_json_string_ext(membre_obj, JSON_C_TO_STRING_PLAIN);

            // Écrire la nouvelle ligne dans le fichier temporaire
            fprintf(temp_file, "%s\n", membre_json_str);

            json_object_put(membre_obj);
        }
    }

    // Si le membre a été trouvé, remplacer le fichier original par le fichier temporaire
    if (found) {
        fclose(membres_file);
        fclose(temp_file);

        if (remove("../bin/membres.json") != 0) {
            printf("Erreur lors de la suppression du fichier membres.json.\n");
            return;
        }
        if (rename("../bin/membres_temp.json", "../bin/membres.json") != 0) {
            printf("Erreur lors du renommage du fichier temporaire.\n");
            return;
        }
    } else {
        // Le membre n'a pas été trouvé, fermer les fichiers sans les modifier
        fclose(membres_file);
        fclose(temp_file);

        // Supprimer le fichier temporaire
        remove("../bin/membres_temp.json");

        printf("Membre non trouvé.\n");
    }
}


void retour_livre(const char* livre_titre, int membre_id) {
    // Ouvrir le fichier "livres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    if (livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier livres.json.\n");
        return;
    }

    // Ouvrir le fichier temporaire
    FILE* temp_file = fopen("../bin/livres_temp.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(livres_file);
        return;
    }

    char buffer[512];
    int livre_trouve = 0;

    // Parcourir le fichier "livres.json" pour trouver le livre spécifique
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* titre = json_object_get_string(titre_obj);

                // Vérifier si le livre correspond aux critères de recherche
                if (strcmp(titre, livre_titre) == 0) {
                    json_object* statut_obj;
                    if (json_object_object_get_ex(livre_obj, "statut", &statut_obj)) {
                        const char* statut = json_object_get_string(statut_obj);
                        if (strcmp(statut, "EMPRUNTE") == 0) {
                            // Modifier le statut du livre
                            json_object_object_del(livre_obj, "statut");
                            json_object_object_add(livre_obj, "statut", json_object_new_string("DISPONIBLE"));

                            json_object_object_del(livre_obj, "date_limite_retour");
                            livre_trouve = 1;
                        }
                    }
                }
            }

            // Convertir l'objet JSON en chaîne de caractères
            const char* livre_json_str = json_object_to_json_string_ext(livre_obj, JSON_C_TO_STRING_PLAIN);

            // Écrire la ligne dans le fichier temporaire
            fprintf(temp_file, "%s\n", livre_json_str);

            json_object_put(livre_obj);
        }
    }

    // Fermer les fichiers
    fclose(livres_file);
    fclose(temp_file);

    if (!livre_trouve) {
        printf("Le livre \"%s\" n'est pas emprunté ou n'existe pas.\n", livre_titre);
        return;
    }

    // Renommer le fichier temporaire en "livres.json"
    int rename_result = rename("../bin/livres_temp.json", "../bin/livres.json");
    if (rename_result != 0) {
        printf("Erreur lors du renommage du fichier temporaire.\n");
        return;
    } else {
        update_retour_membre(membre_id, livre_titre);
    }
}

void update_retour_membre(int membre_id, const char* livre_titre) {
    // Ouvrir le fichier "membres.json"
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier membres.json.\n");
        return;
    }

    // Ouvrir le fichier temporaire
    FILE* temp_file = fopen("../bin/membres_temp.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(membres_file);
        return;
    }

    char buffer[512];
    int membre_trouve = 0;

    // Parcourir le fichier "membres.json" pour trouver le membre spécifique
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* id_obj;
            if (json_object_object_get_ex(membre_obj, "id", &id_obj)) {
                int membre_id_val = json_object_get_int(id_obj);

                // Vérifier si le membre correspond à l'ID spécifié
                if (membre_id_val == membre_id) {
                    json_object* livres_empruntes_obj;
                    if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_obj)) {
                        // Vérifier si le livre est dans la liste des livres empruntés
                        int index = -1;
                        int length = json_object_array_length(livres_empruntes_obj);
                        for (int i = 0; i < length; i++) {
                            json_object* livre_obj = json_object_array_get_idx(livres_empruntes_obj, i);
                            const char* livre = json_object_get_string(livre_obj);
                            if (strcmp(livre, livre_titre) == 0) {
                                index = i;
                                break;
                            }
                        }

                        if (index >= 0) {
                            // Retirer le livre de la liste des livres empruntés
                            json_object_array_del_idx(livres_empruntes_obj, index, 1);

                            // Mettre à jour le nombre de livres empruntés
                            json_object* nb_livres_empruntes_obj;
                            if (json_object_object_get_ex(membre_obj, "nb_livres_empruntes", &nb_livres_empruntes_obj)) {
                                int nb_livres_empruntes = json_object_get_int(nb_livres_empruntes_obj);
                                json_object_set_int(nb_livres_empruntes_obj, nb_livres_empruntes - 1);
                            }

                            membre_trouve = 1;
                        }
                    }
                }
            }

            // Convertir l'objet JSON en chaîne de caractères
            const char* membre_json_str = json_object_to_json_string_ext(membre_obj, JSON_C_TO_STRING_PLAIN);

            // Écrire la ligne dans le fichier temporaire
            fprintf(temp_file, "%s\n", membre_json_str);

            json_object_put(membre_obj);

        }
    }

    // Fermer les fichiers
    fclose(membres_file);
    fclose(temp_file);

    if (!membre_trouve) {
        printf("Le membre avec l'ID %d n'existe pas ou n'a pas emprunté le livre \"%s\".\n", membre_id, livre_titre);
        return;
    }

    // Renommer le fichier temporaire en "membres.json"
    int rename_result = rename("../bin/membres_temp.json", "../bin/membres.json");
    if (rename_result != 0) {
        printf("Erreur lors du renommage du fichier temporaire.\n");
        return;
    } else {
        printf("Le livre %s a été retourné avec succès.\n", livre_titre);
    }
}

void lister_emprunts(int id) {
    // Ouvrir le fichier "membres.json"
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier membres.json.\n");
        return;
    }

    char buffer[512];
    int membre_trouve = 0;

    // Rechercher le membre avec l'ID donné dans le fichier "membres.json"
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* id_obj;
            if (json_object_object_get_ex(membre_obj, "id", &id_obj)) {
                int membre_id = json_object_get_int(id_obj);
                if (membre_id == id) {
                    json_object* livres_empruntes_obj;
                    if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_obj)) {
                        int nb_livres_empruntes = json_object_array_length(livres_empruntes_obj);

                        printf("\nLivres empruntés par le membre avec l'ID %d:\n", id);
                        for (int i = 0; i < nb_livres_empruntes; i++) {
                            json_object* livre_emprunte_obj = json_object_array_get_idx(livres_empruntes_obj, i);
                            const char* livre_emprunte = json_object_get_string(livre_emprunte_obj);
                            printf("- %s\n", livre_emprunte);
                        }

                        membre_trouve = 1;
                    }
                }
            }

            json_object_put(membre_obj);
        }
    }

    // Fermer le fichier "membres.json"
    fclose(membres_file);

    if (!membre_trouve) {
        printf("Aucun membre trouvé avec l'ID %d.\n", id);
    }
}

void lister_membres(const char* titre) {
    // Ouvrir le fichier "livres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    if (livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier \"livres.json\".\n");
        return;
    }

    char buffer[512];
    int livre_trouve = 0;

    // Parcourir le fichier "livres.json" pour trouver le livre spécifique
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* livre_titre = json_object_get_string(titre_obj);
                if (strcmp(livre_titre, titre) == 0) {
                    livre_trouve = 1;
                    break;
                }
            }

            json_object_put(livre_obj);
        }
    }

    // Fermer le fichier "livres.json"
    fclose(livres_file);

    if (!livre_trouve) {
        printf("Le livre \"%s\" n'existe pas.\n", titre);
        return;
    }

    // Ouvrir le fichier "membres.json"
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier \"membres.json\".\n");
        return;
    }

    // Parcourir le fichier "membres.json" pour trouver les membres ayant emprunté le livre
    rewind(membres_file);
    int membre_trouve = 0;
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* livres_empruntes_obj;
            if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_obj)) {
                int nb_livres_empruntes = json_object_array_length(livres_empruntes_obj);

                // Parcourir les livres empruntés par le membre
                for (int i = 0; i < nb_livres_empruntes; i++) {
                    json_object* livre_emprunte_obj = json_object_array_get_idx(livres_empruntes_obj, i);
                    const char* livre_emprunte = json_object_get_string(livre_emprunte_obj);

                    // Vérifier si le livre spécifique est emprunté par le membre
                    if (strcmp(livre_emprunte, titre) == 0) {
                        membre_trouve = 1;

                        // Récupérer le prénom du membre
                        json_object* prenom_obj;
                        if (json_object_object_get_ex(membre_obj, "prenom", &prenom_obj)) {
                            const char* prenom = json_object_get_string(prenom_obj);
                            printf("Le livre \"%s\" a été emprunté par %s\n", titre, prenom);
                        }

                        break;
                    }
                }
            }

            json_object_put(membre_obj);
        }
    }

    // Fermer le fichier "membres.json"
    fclose(membres_file);

    if (!membre_trouve) {
        printf("Aucun membre n'a emprunté le livre \"%s\".\n", titre);
    }
}


void afficher_historique_par_membre(int id) {
    // Ouvrir le fichier "membres.json"
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier membres.json.\n");
        return;
    }

    char buffer[512];

    // Parcourir le fichier "membres.json" pour trouver le membre spécifique
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* id_obj;
            if (json_object_object_get_ex(membre_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);

                if (existing_id == id) {
                    // Vérifier si le champ "historique_emprunt" est un tableau
                    json_object* historique_emprunt_array;
                    if (json_object_object_get_ex(membre_obj, "historique_emprunt", &historique_emprunt_array) &&
                        json_object_get_type(historique_emprunt_array) == json_type_array) {

                        int array_length = json_object_array_length(historique_emprunt_array);

                        printf("Historique d'emprunt pour le membre avec l'ID %d :\n", id);
                        for (int i = 0; i < array_length; i++) {
                            json_object* titre_obj = json_object_array_get_idx(historique_emprunt_array, i);
                            const char* titre = json_object_get_string(titre_obj);
                            printf("- %s\n", titre);
                        }
                        printf("\n");
                    } else {
                        printf("Aucun historique d'emprunt pour le membre avec l'ID %d.\n\n", id);
                    }

                    break;
                }
            }

            json_object_put(membre_obj);
        }
    }

    // Fermer le fichier "membres.json"
    fclose(membres_file);
}

void afficher_historique_par_oeuvre(const char* titre) {
    // Ouvrir le fichier "livres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    if (livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier livres.json.\n");
        return;
    }

    char buffer[512];

    // Parcourir le fichier "livres.json" pour trouver l'objet correspondant au titre spécifié
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* livre_titre = json_object_get_string(titre_obj);

                // Vérifier si le titre correspond à celui recherché
                if (strcmp(livre_titre, titre) == 0) {
                    // Vérifier si le champ "historique_emprunteur" est un tableau
                    json_object* historique_emprunteur_array;
                    if (json_object_object_get_ex(livre_obj, "historique_emprunteur", &historique_emprunteur_array) &&
                        json_object_get_type(historique_emprunteur_array) == json_type_array) {
                        int historique_length = json_object_array_length(historique_emprunteur_array);
                        printf("Historique d'emprunt pour l'oeuvre '%s':\n", titre);
                        for (int i = 0; i < historique_length; i++) {
                            json_object* emprunteur_id_obj = json_object_array_get_idx(historique_emprunteur_array, i);
                            int emprunteur_id = json_object_get_int(emprunteur_id_obj);
                            printf("- ID Emprunteur: %d\n", emprunteur_id);
                        }
                    } else {
                        printf("Aucun historique d'emprunt trouvé pour l'oeuvre '%s'.\n", titre);
                    }

                    break;
                }
            }

            json_object_put(livre_obj);
        }
    }

    // Fermer le fichier "livres.json"
    fclose(livres_file);
}
