#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "membres.h"
#include "livres.h"
#include "json-c/json.h"

int generer_id_unique_membre() {
    FILE *file = fopen("../bin/membres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return -1;
    }

    int max_id = 0;
    char line[512];
    while (fgets(line, sizeof(line), file)) {
        json_object *json_obj = json_tokener_parse(line);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id > max_id) {
                    max_id = existing_id;
                }
            }
        }
        json_object_put(json_obj);
    }

    fclose(file);
    return max_id + 1;
}

void ajouter_membre() {
    Membre nouveauMembre;

    printf("Entrez les informations du nouveau membre :\n");
    
    printf("Prénom : ");
    scanf(" %99[^\n]", nouveauMembre.prenom);

    printf("Nom : ");
    scanf(" %99[^\n]", nouveauMembre.nom);

    printf("Date de naissance (xx-xx-xx) : ");
    scanf(" %11[^\n]", nouveauMembre.date_naissance);

    // Générer un identifiant unique pour le livre
    int nouveau_id = generer_id_unique_membre();
    nouveauMembre.id = nouveau_id;

    nouveauMembre.nb_livres_empruntes = 0;

    // Créer un objet JSON pour le livre
    json_object *data_membre = json_object_new_object();

    // Ajout des valeurs du livre à l'objet membre JSON
    json_object_object_add(data_membre, "id", json_object_new_int(nouveauMembre.id));
    json_object_object_add(data_membre, "prenom", json_object_new_string(nouveauMembre.prenom));
    json_object_object_add(data_membre, "nom", json_object_new_string(nouveauMembre.nom));
    json_object_object_add(data_membre, "date_naissance", json_object_new_string(nouveauMembre.date_naissance));
    json_object_object_add(data_membre, "livres_empruntes", json_object_new_array()); // Tableau vide
    json_object_object_add(data_membre, "nb_livres_empruntes", json_object_new_int(nouveauMembre.nb_livres_empruntes)); // Valeur initiale

    // Convertir l'objet JSON en chaîne de caractères
    const char *json_str = json_object_to_json_string_ext(data_membre, JSON_C_TO_STRING_PLAIN);
   
    // Sauvegarder le livre dans un fichier
    FILE *file = fopen("membres.json", "a");
    if (file) {
        fprintf(file, "%s\n", json_str);
        fclose(file);
        printf("Livre ajouté avec succès !\n");
    } else {
        printf("Erreur lors de l'ouverture du fichier.\n");
    }

    // Libérer la mémoire
    json_object_put(data_membre);

}

void modifier_membre(int membre_id) {
    FILE *file = fopen("../bin/membres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    FILE *temp_file = fopen("../bin/temp_membres.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(file);
        return;
    }

    char buffer[512];
    int membre_found = 0;

    while (fgets(buffer, sizeof(buffer), file)) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == membre_id) {
                    membre_found = 1;

                    Membre membre;
                    int choix;
                    printf("Que voulez-vous modifier ?\n");
                    printf("1. Prénom\n");
                    printf("2. Nom\n");
                    printf("3. Date de naissance\n");
                    printf("Votre choix : ");
                    scanf("%d", &choix);
                    getchar(); // Pour consommer le caractère de saut de ligne

                    switch (choix) {
                        case 1:
                            printf("Nouveau prénom : ");
                            scanf(" %99[^\n]", membre.prenom);
                            json_object_object_add(json_obj, "prenom", json_object_new_string(membre.prenom));
                            break;
                        case 2:
                            printf("Nouveau nom : ");
                            scanf(" %99[^\n]", membre.nom);
                            json_object_object_add(json_obj, "nom", json_object_new_string(membre.nom));
                            break;
                        case 3:
                            printf("Nouvelle date de naissance : ");
                            scanf(" %99[^\n]", membre.date_naissance);
                            json_object_object_add(json_obj, "date_naissance", json_object_new_string(membre.date_naissance));
                            break;
                        default:
                            printf("Choix invalide.\n");
                            json_object_put(json_obj);
                            continue;
                    }
                }
            }

            const char *json_str = json_object_to_json_string_ext(json_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_file, "%s\n", json_str);

            json_object_put(json_obj);
        } else {
            fprintf(temp_file, "%s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (membre_found) {
        if (rename("../bin/temp_membres.json", "../bin/membres.json") == 0) {
            printf("Le membre a été modifié avec succès.\n");
        } else {
            printf("Erreur lors de la modification du membre.\n");
        }
    } else {
        remove("../bin/temp_membres.json");
        printf("Le membre avec l'ID %d n'existe pas.\n", membre_id);
    }
}

void supprimer_membre(int membre_id) {
    FILE *file = fopen("../bin/membres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    FILE *temp_file = fopen("../bin/temp_membres.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(file);
        return;
    }

    char buffer[512];
    int membre_found = 0;

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == membre_id) {
                    membre_found = 1;
                    json_object_put(json_obj);
                    continue;
                }
            }
            const char *json_str = json_object_to_json_string_ext(json_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_file, "%s\n", json_str);
            json_object_put(json_obj);
        } else {
            fprintf(temp_file, "%s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (membre_found) {
        if (rename("../bin/temp_membres.json", "../bin/membres.json") == 0) {
            printf("Le membre a été modifié avec succès.\n");
        } else {
            printf("Erreur lors de la modification du membre.\n");
        }
    } else {
        remove("../bin/temp_membres.json");
        printf("Le membre avec l'ID %d n'existe pas.\n", membre_id);
    }
}

void afficher_membres() {
    // Ouvrir le fichier livres.json en mode lecture
    FILE* file = fopen("membres.json", "r");
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier membres.json");
        return;
    }
    
    char buffer[BUFSIZ];
    while (fgets(buffer, sizeof(buffer), file)) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj, *prenom_obj, *nom_obj, *date_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)
                && json_object_object_get_ex(json_obj, "prenom", &prenom_obj)
                && json_object_object_get_ex(json_obj, "nom", &nom_obj)
                && json_object_object_get_ex(json_obj, "date_naissance", &date_obj)) {
                printf("Id : %s\n", json_object_get_string(id_obj));    
                printf("Prénom : %s\n", json_object_get_string(prenom_obj));
                printf("Nom : %s\n", json_object_get_string(nom_obj));
                printf("Date de naissance : %s\n\n", json_object_get_string(date_obj));
            }
        }
    }

    // Fermer le fichier
    fclose(file);
}

void emprunter_livre(int membre_id, const char* livre_titre) {
    // Ouvrir les fichiers "livres.json" et "membres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (livres_file == NULL || membres_file == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    // Ouvrir le fichier temporaire pour les modifications
    FILE* temp_livres_file = fopen("../bin/temp_livres.json", "w");
    if (temp_livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire pour les livres.\n");
        fclose(livres_file);
        fclose(membres_file);
        return;
    }

    char buffer[512];
    int livre_trouve = 0;
    int membre_trouve = 0;

    // Parcourir le fichier "livres.json" pour trouver le livre spécifique
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* titre = json_object_get_string(titre_obj);
                if (strcmp(titre, livre_titre) == 0) {
                    // Vérifier si le livre est déjà emprunté
                    json_object* statut_obj;
                    if (json_object_object_get_ex(livre_obj, "statut", &statut_obj)) {
                        const char* statut = json_object_get_string(statut_obj);
                        if (strcmp(statut, "EMPRUNTE") == 0) {
                            printf("Le livre \"%s\" est déjà emprunté.\n", livre_titre);
                            livre_trouve = 1;
                            break;
                        }
                    }

                    livre_trouve = 1;

                    // Modifier le statut du livre
                    json_object_object_add(livre_obj, "statut", json_object_new_string("EMPRUNTE"));

                    // Convertir l'objet JSON modifié en chaîne de caractères
                    const char* livre_json_str = json_object_to_json_string_ext(livre_obj, JSON_C_TO_STRING_PLAIN);

                    // Sauvegarder les modifications dans le fichier temporaire
                    fprintf(temp_livres_file, "%s\n", livre_json_str);
                }
            }

            json_object_put(livre_obj);
        }
    }

    // Fermer les fichiers "livres.json" et temporaire des livres
    fclose(livres_file);
    fclose(temp_livres_file);

    // Vérifier si le livre a été trouvé
    if (!livre_trouve) {
        printf("Le livre \"%s\" n'existe pas ou est déjà emprunté.\n", livre_titre);
        fclose(membres_file);
        remove("../bin/temp_livres.json");
        return;
    }
  
    // Parcourir le fichier "membres.json" pour trouver le membre
    FILE* temp_membres_file = fopen("../bin/temp_membres.json", "w");
    if (temp_membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire pour les membres.\n");
        fclose(membres_file);
        remove("../bin/temp_livres.json");
        return;
    }

    // Parcourir les objets dans le fichier "membres.json"
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* id_obj;
            if (json_object_object_get_ex(membre_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == membre_id) {
                    membre_trouve = 1;

                    // Ajouter le livre emprunté au tableau des livres empruntés
                    json_object* livres_empruntes_obj;
                    if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_obj)) {
                        int nb_livres_empruntes = json_object_array_length(livres_empruntes_obj);
                        json_object_array_add(livres_empruntes_obj, json_object_new_string(livre_titre));
                        json_object_object_add(membre_obj, "nb_livres_empruntes", json_object_new_int(nb_livres_empruntes + 1));
                    }
                }
            }

            const char* membre_json_str = json_object_to_json_string_ext(membre_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_membres_file, "%s\n", membre_json_str);
            json_object_put(membre_obj);
        }
    }

    // Fermer les fichiers "membres.json" et temporaire des membres
    fclose(membres_file);
    fclose(temp_membres_file);

    // Renommer le fichier temporaire pour remplacer le fichier d'origine
    if (rename("../bin/temp_membres.json", "../bin/membres.json") != 0) {
        printf("Erreur lors du remplacement du fichier membres.json.\n");
        remove("../bin/temp_livres.json");
        return;
    }

    if (!membre_trouve) {
        printf("Membre introuvable.\n");
    } else {
        printf("Livre emprunté avec succès !\n");
    }
}


void retour_livre(const char* livre_titre) {
    // Ouvrir les fichiers "livres.json" et "membres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (livres_file == NULL || membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    // Ouvrir les fichiers temporaires pour les modifications
    FILE* temp_livres_file = fopen("../bin/temp_livres.json", "w");
    FILE* temp_membres_file = fopen("../bin/temp_membres.json", "w");
    if (temp_livres_file == NULL || temp_membres_file == NULL) {
        printf("Erreur lors de l'ouverture des fichiers temporaires.\n");
        fclose(livres_file);
        fclose(membres_file);
        return;
    }

    char buffer[512];
    int livre_trouve = 0;

    // Rechercher le livre dans le fichier "livres.json"
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* titre = json_object_get_string(titre_obj);
                if (strcmp(titre, livre_titre) == 0) {
                    json_object* statut_obj;
                    if (json_object_object_get_ex(livre_obj, "statut", &statut_obj)) {
                        const char* statut = json_object_get_string(statut_obj);
                        if (strcmp(statut, "EMPRUNTE") == 0) {
                            livre_trouve = 1;

                            // Modifier le statut du livre
                            json_object_object_add(livre_obj, "statut", json_object_new_string("DISPONIBLE"));

                            // Convertir l'objet JSON modifié en chaîne de caractères
                            const char* livre_json_str = json_object_to_json_string_ext(livre_obj, JSON_C_TO_STRING_PLAIN);

                            // Sauvegarder les modifications dans le fichier temporaire des livres
                            fprintf(temp_livres_file, "%s\n", livre_json_str);
                        }
                    }
                }
            }
        }

        json_object_put(livre_obj);
    }

    // Fermer le fichier "livres.json"
    fclose(livres_file);

    // Vérifier si le livre a été trouvé et mis à jour
    if (!livre_trouve) {
        printf("Le livre \"%s\" n'existe pas ou n'est pas emprunté.\n", livre_titre);
        fclose(membres_file);
        fclose(temp_livres_file);
        fclose(temp_membres_file);
        remove("../bin/temp_livres.json");
        remove("../bin/temp_membres.json");
        return;
    }

        // Rechercher les membres ayant emprunté le livre dans le fichier "membres.json"
    int membres_modifies = 0;
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* livres_empruntes_obj;
            if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_obj)) {
                int nb_livres_empruntes = json_object_array_length(livres_empruntes_obj);
                int livre_retire = 0;

                // Parcourir les livres empruntés par le membre
                for (int i = 0; i < nb_livres_empruntes; i++) {
                    json_object* livre_emprunte_obj = json_object_array_get_idx(livres_empruntes_obj, i);
                    const char* livre_emprunte = json_object_get_string(livre_emprunte_obj);

                    // Vérifier si le livre retiré correspond à un livre emprunté par le membre
                    if (strcmp(livre_emprunte, livre_titre) == 0) {
                        // Supprimer le livre de la liste des livres empruntés
                        json_object_array_del_idx(livres_empruntes_obj, i, 1);
                        livre_retire = 1;
                        break;
                    }
                }

                // Mettre à jour le nombre de livres empruntés par le membre
                if (livre_retire) {
                    json_object_object_add(membre_obj, "nb_livres_empruntes", json_object_new_int(nb_livres_empruntes - 1));
                    membres_modifies = 1;
                }
            }

            const char* membre_json_str = json_object_to_json_string_ext(membre_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_membres_file, "%s\n", membre_json_str);
            json_object_put(membre_obj);
        }
    }

    // Fermer le fichier "membres.json"
    fclose(membres_file);

    // Fermer les fichiers temporaires
    fclose(temp_livres_file);
    fclose(temp_membres_file);

    // Renommer les fichiers temporaires pour remplacer les fichiers d'origine
    if (rename("../bin/temp_livres.json", "../bin/livres.json") != 0) {
        printf("Erreur lors du remplacement du fichier livres.json.\n");
        remove("../bin/temp_livres.json");
        remove("../bin/temp_membres.json");
        return;
    }

    if (rename("../bin/temp_membres.json", "../bin/membres.json") != 0) {
        printf("Erreur lors du remplacement du fichier membres.json.\n");
        remove("../bin/temp_livres.json");
        remove("../bin/temp_membres.json");
        return;
    }

    if (!membres_modifies) {
        printf("Aucun membre n'a emprunté le livre \"%s\".\n", livre_titre);
    } else {
        printf("Livre \"%s\" retiré avec succès !\n", livre_titre);
    }
}

void lister_emprunts(int id) {
    // Ouvrir le fichier "membres.json"
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier membres.json.\n");
        return;
    }

    char buffer[512];
    int membre_trouve = 0;

    // Rechercher le membre avec l'ID donné dans le fichier "membres.json"
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* id_obj;
            if (json_object_object_get_ex(membre_obj, "id", &id_obj)) {
                int membre_id = json_object_get_int(id_obj);
                if (membre_id == id) {
                    json_object* livres_empruntes_obj;
                    if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_obj)) {
                        int nb_livres_empruntes = json_object_array_length(livres_empruntes_obj);

                        printf("\nLivres empruntés par le membre avec l'ID %d:\n", id);
                        for (int i = 0; i < nb_livres_empruntes; i++) {
                            json_object* livre_emprunte_obj = json_object_array_get_idx(livres_empruntes_obj, i);
                            const char* livre_emprunte = json_object_get_string(livre_emprunte_obj);
                            printf("- %s\n", livre_emprunte);
                        }

                        membre_trouve = 1;
                    }
                }
            }

            json_object_put(membre_obj);
        }
    }

    // Fermer le fichier "membres.json"
    fclose(membres_file);

    if (!membre_trouve) {
        printf("Aucun membre trouvé avec l'ID %d.\n", id);
    }
}

void lister_membres(const char* titre) {
    // Ouvrir le fichier "livres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    if (livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier \"livres.json\".\n");
        return;
    }

    char buffer[512];
    int livre_trouve = 0;

    // Parcourir le fichier "livres.json" pour trouver le livre spécifique
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* livre_titre = json_object_get_string(titre_obj);
                if (strcmp(livre_titre, titre) == 0) {
                    livre_trouve = 1;
                    break;
                }
            }

            json_object_put(livre_obj);
        }
    }

    // Fermer le fichier "livres.json"
    fclose(livres_file);

    if (!livre_trouve) {
        printf("Le livre \"%s\" n'existe pas.\n", titre);
        return;
    }

    // Ouvrir le fichier "membres.json"
    FILE* membres_file = fopen("../bin/membres.json", "r");
    if (membres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier \"membres.json\".\n");
        return;
    }

    // Parcourir le fichier "membres.json" pour trouver les membres ayant emprunté le livre
    rewind(membres_file);
    int membre_trouve = 0;
    while (fgets(buffer, sizeof(buffer), membres_file)) {
        json_object* membre_obj = json_tokener_parse(buffer);
        if (membre_obj != NULL) {
            json_object* livres_empruntes_obj;
            if (json_object_object_get_ex(membre_obj, "livres_empruntes", &livres_empruntes_obj)) {
                int nb_livres_empruntes = json_object_array_length(livres_empruntes_obj);

                // Parcourir les livres empruntés par le membre
                for (int i = 0; i < nb_livres_empruntes; i++) {
                    json_object* livre_emprunte_obj = json_object_array_get_idx(livres_empruntes_obj, i);
                    const char* livre_emprunte = json_object_get_string(livre_emprunte_obj);

                    // Vérifier si le livre spécifique est emprunté par le membre
                    if (strcmp(livre_emprunte, titre) == 0) {
                        membre_trouve = 1;

                        // Récupérer le prénom du membre
                        json_object* prenom_obj;
                        if (json_object_object_get_ex(membre_obj, "prenom", &prenom_obj)) {
                            const char* prenom = json_object_get_string(prenom_obj);
                            printf("Le livre \"%s\" a été emprunté par %s\n", titre, prenom);
                        }

                        break;
                    }
                }
            }

            json_object_put(membre_obj);
        }
    }

    // Fermer le fichier "membres.json"
    fclose(membres_file);

    if (!membre_trouve) {
        printf("Aucun membre n'a emprunté le livre \"%s\".\n", titre);
    }
}
