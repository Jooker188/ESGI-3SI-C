#ifndef LIVRES_H
#define LIVRES_H

#define MAX_LIVRES 100
#define MAX_TITRE 100
#define MAX_AUTEUR 100
#define MAX_CATEGORIE 50

typedef enum {
    ROMAN,
    SCIENCES,
    HISTORIQUE,
    POLICIER,
    MAGIQUE,
    AUCUNE
} Categorie;

typedef enum {
    DISPONIBLE,
    EMPRUNTE,
    RESERVE
} Statut;

typedef struct {
    int id;
    char titre[MAX_TITRE];
    char auteur[MAX_AUTEUR];
    char categorie[MAX_CATEGORIE];
    Statut statut;
} Livre;

void ajouter_livre();
void supprimer_livre(int livre_id);
void modifier_livre(int livre_id);
void rechercher_livre();
void menuLivres();
char* statutToString(Statut statut);
int generer_id_unique();
Categorie menu_categories();
const char* categorieToString(Categorie categorie);
void afficher_livres();
int* verifier_date_limite_retour(int* taille_exclus);

#endif
