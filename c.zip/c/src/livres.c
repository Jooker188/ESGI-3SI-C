#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "livres.h"
#include "membres.h"
#include "json-c/json.h"
#include <time.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <json-c/json.h>

int generer_id_unique() {
    FILE *file = fopen("../bin/livres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return -1;
    }

    int max_id = 0;
    char line[512];
    while (fgets(line, sizeof(line), file)) {
        json_object *json_obj = json_tokener_parse(line);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id > max_id) {
                    max_id = existing_id;
                }
            }
        }
        json_object_put(json_obj);
    }

    fclose(file);
    return max_id + 1;
}

void ajouter_livre() {
    // Vérifier si le nombre maximum de livres est atteint

    Livre nouveauLivre;

    printf("Entrez les informations du nouveau livre :\n");
    
    printf("Titre : ");
    scanf(" %29[^\n]", nouveauLivre.titre);

    printf("Auteur : ");
    scanf(" %29[^\n]", nouveauLivre.auteur);

    // Demande de la categorie puis conversion en str
    Categorie userCategorie = menu_categories();
    const char* categorieStr = categorieToString(userCategorie);
    strcpy(nouveauLivre.categorie, categorieStr);

    // Générer un identifiant unique pour le livre
    int nouveau_id = generer_id_unique();
    nouveauLivre.id = nouveau_id;

    nouveauLivre.statut = DISPONIBLE; // Par défaut, le livre est disponible

    // Créer un objet JSON pour le livre
    json_object *data_livre = json_object_new_object();

    // Ajout des valeurs du livre à l'objet livre JSON
    json_object_object_add(data_livre, "id", json_object_new_int(nouveauLivre.id));
    json_object_object_add(data_livre, "titre", json_object_new_string(nouveauLivre.titre));
    json_object_object_add(data_livre, "auteur", json_object_new_string(nouveauLivre.auteur));
    json_object_object_add(data_livre, "categorie", json_object_new_string(nouveauLivre.categorie));
    json_object_object_add(data_livre, "statut", json_object_new_string(statutToString(nouveauLivre.statut)));

    // Convertir l'objet JSON en chaîne de caractères
    const char *json_str = json_object_to_json_string_ext(data_livre, JSON_C_TO_STRING_PLAIN);
   
    // Sauvegarder le livre dans un fichier
    FILE *file = fopen("livres.json", "a");
    if (file) {
        fprintf(file, "%s\n", json_str);
        fclose(file);
        printf("Livre ajouté avec succès !\n");
    } else {
        printf("Erreur lors de l'ouverture du fichier.\n");
    }

    // Libérer la mémoire
    json_object_put(data_livre);

}

void supprimer_livre(int livre_id) {
    FILE *file = fopen("../bin/livres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    FILE *temp_file = fopen("../bin/livres_temp.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(file);
        return;
    }

    char buffer[512];
    int livre_trouve = 0;

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == livre_id) {
                    livre_trouve = 1;
                    json_object_put(json_obj);
                    continue;
                }
            }
            const char *json_str = json_object_to_json_string_ext(json_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_file, "%s\n", json_str);
            json_object_put(json_obj);
        } else {
            fprintf(temp_file, "%s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (livre_trouve) {
        // Remplacement du fichier d'origine par le fichier temporaire
        remove("../bin/livres.json");
        rename("../bin/livres_temp.json", "../bin/livres.json");
        printf("Le livre a été supprimé avec succès.\n");
    } else {
        remove("../bin/livres_temp.json");
        printf("Le livre avec l'ID %d n'existe pas.\n", livre_id);
    }
}



void modifier_livre(int livre_id) {
    FILE *file = fopen("../bin/livres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    FILE *temp_file = fopen("../bin/temp_livres.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(file);
        return;
    }

    char buffer[512];
    int livre_found = 0;

    while (fgets(buffer, sizeof(buffer), file)) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == livre_id) {
                    livre_found = 1;

                    Livre livre;
                    int choix;
                    printf("Que voulez-vous modifier ?\n");
                    printf("1. Titre\n");
                    printf("2. Auteur\n");
                    printf("3. Catégorie\n");
                    printf("Votre choix : ");
                    scanf("%d", &choix);
                    getchar(); // Pour consommer le caractère de saut de ligne

                    switch (choix) {
                        case 1:
                            printf("Nouveau titre : ");
                            scanf(" %99[^\n]", livre.titre);
                            json_object_object_add(json_obj, "titre", json_object_new_string(livre.titre));
                            break;
                        case 2:
                            printf("Nouvel auteur : ");
                            scanf(" %99[^\n]", livre.auteur);
                            json_object_object_add(json_obj, "auteur", json_object_new_string(livre.auteur));
                            break;
                        case 3:
                            // Demande de la categorie puis conversion en str
                            Categorie userCategorie = menu_categories();
                            const char* categorieStr = categorieToString(userCategorie);
                            strcpy(livre.categorie, categorieStr);
                            json_object_object_add(json_obj, "categorie", json_object_new_string(livre.categorie));
                            break;
                        default:
                            printf("Choix invalide.\n");
                            json_object_put(json_obj);
                            continue;
                    }
                }
            }

            const char *json_str = json_object_to_json_string_ext(json_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_file, "%s\n", json_str);

            json_object_put(json_obj);
        } else {
            fprintf(temp_file, "%s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (livre_found) {
        if (rename("../bin/temp_livres.json", "../bin/livres.json") == 0) {
            printf("Le livre a été modifié avec succès.\n");
        } else {
            printf("Erreur lors de la modification du livre.\n");
        }
    } else {
        remove("../bin/temp_livres.json");
        printf("Le livre avec l'ID %d n'existe pas.\n", livre_id);
    }
}
   
void afficher_livres() {
    // Ouvrir le fichier livres.json en mode lecture
    FILE* file = fopen("livres.json", "r");
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier livres.json");
        return;
    }

    printf("%s", "\n------------ Catalogue de la bibliothèque ------------\n");

    char buffer[BUFSIZ];
    while (fgets(buffer, sizeof(buffer), file)) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj, *titre_obj, *auteur_obj, *categorie_obj, *statut_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)
                && json_object_object_get_ex(json_obj, "titre", &titre_obj)
                && json_object_object_get_ex(json_obj, "auteur", &auteur_obj)
                && json_object_object_get_ex(json_obj, "categorie", &categorie_obj)
                && json_object_object_get_ex(json_obj, "statut", &statut_obj)){
                printf("Id : %s\n", json_object_get_string(id_obj));
                printf("Titre : %s\n", json_object_get_string(titre_obj));
                printf("Auteur : %s\n", json_object_get_string(auteur_obj));
                printf("Catégorie : %s\n", json_object_get_string(categorie_obj));
                printf("Statut : %s\n\n", json_object_get_string(statut_obj));
            }
        }
    }

    // Fermer le fichier
    fclose(file);
}

void rechercher_livre() {
    int choix;
    printf("Rechercher par :\n");
    printf("1. Titre\n");
    printf("2. Auteur\n");
    printf("3. Catégorie\n");
    printf("Votre choix : ");
    scanf(" %2d", &choix);

    // Ouvrir le fichier livres.json en mode lecture
    FILE* file = fopen("livres.json", "r");
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier livres.json");
        return;
    }

    char buffer[BUFSIZ];
    int livre_trouve = 0;

    switch (choix) {
        case 1: {
            char titre_recherche[100];
            printf("Entrez le titre à rechercher : ");
            scanf(" %[^\n]", titre_recherche);

            while (fgets(buffer, sizeof(buffer), file)) {
                json_object* json_obj = json_tokener_parse (buffer);
                if (json_obj != NULL) {
                    json_object* titre_obj;
                    if (json_object_object_get_ex(json_obj, "titre", &titre_obj)) {
                        const char* titre = json_object_get_string(titre_obj);
                        if (strcmp(titre, titre_recherche) == 0) {
                            printf("\n -------------- Livre trouvé --------------\n");
                            printf("Titre: %s\n", titre);

                            json_object* id_obj;
                            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                                int id = json_object_get_int(id_obj);
                                printf("Id : %d\n", id);
                            }

                            json_object* auteur_obj;
                            if (json_object_object_get_ex(json_obj, "auteur", &auteur_obj)) {
                                const char* auteur = json_object_get_string(auteur_obj);
                                printf("Auteur: %s\n", auteur);
                            }

                            json_object* categorie_obj;
                            if (json_object_object_get_ex(json_obj, "categorie", &categorie_obj)) {
                                const char* categorie = json_object_get_string(categorie_obj);
                                printf("Catégorie: %s\n", categorie);
                            }
            
                            json_object* statut_obj;
                            if (json_object_object_get_ex(json_obj, "statut", &statut_obj)) {
                                const char* statut = json_object_get_string(statut_obj);
                                printf("Statut: %s\n", statut);
                            }

                            json_object* emprunteur_obj;
                            if (json_object_object_get_ex(json_obj, "emprunteur", &emprunteur_obj)) {
                                int emprunteur = json_object_get_int(emprunteur_obj);
                                printf("Emprunteur: %d\n", emprunteur);
                            }

                            livre_trouve = 1;
                            break;  // Sortir de la boucle car le livre a été trouvé
                        }
                    }
                }
            }
            break;
        }
        case 2: {
            char auteur_recherche[100];
            printf("Entrez l'auteur à rechercher : ");
            scanf(" %[^\n]", auteur_recherche);

            int livres_trouves = 0; // Compteur pour les livres trouvés

            Livre livres_trouves_list[MAX_LIVRES]; // Limitez le nombre de livres trouvés à 100 pour cet exemple

            while (fgets(buffer, sizeof(buffer), file)) {
                json_object* json_obj = json_tokener_parse(buffer);
                if (json_obj != NULL) {
                    json_object* auteur_obj;
                    if (json_object_object_get_ex(json_obj, "auteur", &auteur_obj)) {
                        const char* auteur = json_object_get_string(auteur_obj);
                        if (strcmp(auteur, auteur_recherche) == 0) {
                            Livre livre;

                            livre.id = json_object_get_int(json_object_object_get(json_obj, "id"));
                            strcpy(livre.titre, json_object_get_string(json_object_object_get(json_obj, "titre")));
                            strcpy(livre.categorie, json_object_get_string(json_object_object_get(json_obj, "categorie")));
                            
                            livre.statut = json_object_get_int(json_object_object_get(json_obj, "statut"));

                            livres_trouves_list[livres_trouves] = livre;
                            livres_trouves++;
                            livre_trouve = 1;
                            continue;
                        }
                    }
                }
            }
            printf("%d", livres_trouves);
            if (livres_trouves > 0) {
                printf("\n -------------- Livres de l'auteur %s --------------\n", auteur_recherche);
                for (int i = 0; i < livres_trouves; i++) {
                    printf("Livre %d:\n", i + 1);
                    printf("Id: %d\n", livres_trouves_list[i].id);
                    printf("Titre: %s\n", livres_trouves_list[i].titre);
                    printf("Catégorie: %s\n", livres_trouves_list[i].categorie);
                    const char* statut_str;
                    switch (livres_trouves_list[i].statut) {
                        case DISPONIBLE:
                            statut_str = "DISPONIBLE";
                            break;
                        case EMPRUNTE:
                            statut_str = "EMPRUNTE";
                            break;
                        case RESERVE:
                            statut_str = "RESERVE";
                            break;
                        default:
                            statut_str = "Inconnu";
                            break;
                    }
                    printf("Statut: %s\n", statut_str);

                }
            } else {
                printf("Aucun livre trouvé pour l'auteur spécifié.\n");
            }

            break;
        }

        case 3: {
            char categorie_recherche[100];
            printf("Entrez la catégorie à rechercher : ");
            scanf(" %[^\n]", categorie_recherche);

            int livres_trouves = 0; // Compteur pour les livres trouvés

            Livre livres_trouves_list[MAX_LIVRES]; // Limitez le nombre de livres trouvés à 100 pour cet exemple

            while (fgets(buffer, sizeof(buffer), file)) {
                json_object* json_obj = json_tokener_parse(buffer);
                if (json_obj != NULL) {
                    json_object* categorie_obj;
                    if (json_object_object_get_ex(json_obj, "categorie", &categorie_obj)) {
                        const char* categorie = json_object_get_string(categorie_obj);
                        if (strcmp(categorie, categorie_recherche) == 0) {
                            Livre livre;

                            livre.id = json_object_get_int(json_object_object_get(json_obj, "id"));
                            strcpy(livre.titre, json_object_get_string(json_object_object_get(json_obj, "titre")));
                            strcpy(livre.auteur, json_object_get_string(json_object_object_get(json_obj, "auteur")));

                            // Récupérer la valeur entière du champ "statut" du JSON
                            int statut_int = json_object_get_int(json_object_object_get(json_obj, "statut"));

                            // Convertir la valeur entière en type Statut
                            Statut statut;
                            switch (statut_int) {
                                case 0:
                                    statut = DISPONIBLE;
                                    break;
                                case 1:
                                    statut = EMPRUNTE;
                                    break;
                                case 2:
                                    statut = RESERVE;
                                    break;
                                default:
                                    statut = DISPONIBLE; // Valeur par défaut en cas d'erreur
                                    break;
                            }

                            livre.statut = statut;

                            livres_trouves_list[livres_trouves] = livre;
                            livres_trouves++;
                            livre_trouve = 1;
                        }
                    }
                }
            }

            if (livres_trouves > 0) {
                printf("\n -------------- Livres de la catégorie %s --------------\n", categorie_recherche);
                for (int i = 0; i < livres_trouves; i++) {
                    printf("Livre %d:\n", i + 1);
                    printf("Id: %d\n", livres_trouves_list[i].id);
                    printf("Titre: %s\n", livres_trouves_list[i].titre);
                    printf("Auteur: %s\n", livres_trouves_list[i].auteur);

                    // Afficher le statut du livre
                    const char* statut_str;
                    switch (livres_trouves_list[i].statut) {
                        case DISPONIBLE:
                            statut_str = "DISPONIBLE";
                            break;
                        case EMPRUNTE:
                            statut_str = "EMPRUNTE";
                            break;
                        case RESERVE:
                            statut_str = "RESERVE";
                            break;
                        default:
                            statut_str = "Inconnu";
                            break;
                    }
                    printf("Statut: %s\n", statut_str);

                }
            } else {
                printf("Aucun livre trouvé pour la catégorie spécifiée.\n");
            }

            break;
        }
        default:
            printf("Choix invalide.\n");
            break;
    }

    if (!livre_trouve) {
        printf("Aucun livre correspondant à la recherche.\n");
    }

    // Fermer le fichier
    fclose(file);
}


char* statutToString(Statut statut) {
    switch (statut) {
        case DISPONIBLE:
            return "DISPONIBLE";
        case EMPRUNTE:
            return "EMPRUNTE";
        case RESERVE:
            return "RESERVE";
        default:
            return "INCONNU";
    }
}


Categorie menu_categories() {
    Categorie categorie = AUCUNE;
    int check;
    int choix = 0;
    // Boucle pour le sous-menu "categorie"
    while (choix != 5) {
        printf("\n********* Sélectionner une catégorie *********\n");
        printf("1. ROMAN\n");
        printf("2. SCIENCES\n");
        printf("3. HISTORIQUE\n");
        printf("4. POLICIER\n");
        printf("5. MAGIQUE\n");
        printf("\nEntrez votre choix : ");
        
        check = scanf("%d", &choix);

        if (check != 1) {
            printf("Saisie invalide. Veuillez saisir un nombre.\n");
            while (getchar() != '\n'); // Vider le flux d'entrée en vidant le tampon
        }
        else{
            switch (choix) {
                case 1:
                    categorie = ROMAN;
                    break;
                case 2:
                    categorie = SCIENCES;
                    break;
                case 3:
                    categorie = HISTORIQUE;
                    break;
                case 4:
                    categorie = POLICIER;
                    break;
                case 5:
                    categorie = MAGIQUE;
                    break;
                default:
                    printf("Choix invalide. Veuillez réessayer.\n");
                    break;
            }
        }
        if (categorie != AUCUNE) {
            break;
        }
    }

    return categorie;
}

const char* categorieToString(Categorie categorie) {
    switch (categorie) {
        case AUCUNE:
            return "Aucune";
        case ROMAN:
            return "Roman";
        case SCIENCES:
            return "Sciences";
        case HISTORIQUE:
            return "Historique";
        case POLICIER:
            return "Policier";
        case MAGIQUE:
            return "Magique";
        default:
            return "Inconnue";
    }
}

void verifier_date_limite_retour() {
    // Ouvrir le fichier "livres.json"
    FILE* livres_file = fopen("../bin/livres.json", "r");
    if (livres_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier livres.json.\n");
        return;
    }

    char buffer[512];
    FILE* fichier_exclusions = fopen("exclusion.txt", "w");
    if (fichier_exclusions == NULL) {
        printf("Erreur lors de l'ouverture du fichier d'exclusions.\n");
        fclose(livres_file);
        return;
    }

    int dernier_emprunteur_id = -1; // Valeur par défaut pour dernier_emprunteur_id

    
    // Parcourir le fichier "livres.json" pour trouver les livres
    while (fgets(buffer, sizeof(buffer), livres_file)) {
        json_object* livre_obj = json_tokener_parse(buffer);
        if (livre_obj != NULL) {
            json_object* titre_obj;
            if (json_object_object_get_ex(livre_obj, "titre", &titre_obj)) {
                const char* titre = json_object_get_string(titre_obj);

                json_object* date_limite_retour_obj;
                if (json_object_object_get_ex(livre_obj, "date_limite_retour", &date_limite_retour_obj)) {
                    time_t date_limite_retour = (time_t) json_object_get_int64(date_limite_retour_obj);

                    // Obtenir la date et l'heure actuelles
                    time_t now = time(NULL);

                    // Comparer les timestamps
                    if (now > date_limite_retour) {
                        // La date limite est dépassée
                        printf("\n[ALERTE] La date limite de retour du livre %s est dépassée.", titre);
                        
                        json_object* historique_emprunteur_array;
                        if (json_object_object_get_ex(livre_obj, "historique_emprunteur", &historique_emprunteur_array) &&
                            json_object_get_type(historique_emprunteur_array) == json_type_array) {
                            
                            int array_length = json_object_array_length(historique_emprunteur_array);
                            if (array_length > 0) {
                                // Récupérer le dernier élément du tableau "historique_emprunteur"
                                json_object* dernier_emprunteur_obj = json_object_array_get_idx(historique_emprunteur_array, array_length - 1);
                                int dernier_emprunteur = json_object_get_int(dernier_emprunteur_obj);


                                printf("\n[ALERTE] Membre ID %d exclu jusqu'au retour du livre\n", dernier_emprunteur);
                
                            }
                            else{
                                printf("Aucun retard d'emprunt.\n");
                            }
                        }
                    }
                    
                }
            }

            json_object_put(livre_obj);
        }
    }

    // Écrire l'ID de l'emprunteur dans le fichier d'exclusions s'il existe
    if (dernier_emprunteur_id != -1) {
        fprintf(fichier_exclusions, "%d\n", dernier_emprunteur_id);
    }

    // Fermer le fichier
    fclose(livres_file);

}
