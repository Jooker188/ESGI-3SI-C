#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "livres.h"
#include "membres.h"
#include "json-c/json.h"

#include <stdbool.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <json-c/json.h>

int generer_id_unique() {
    FILE *file = fopen("../bin/livres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return -1;
    }

    int max_id = 0;
    char line[512];
    while (fgets(line, sizeof(line), file)) {
        json_object *json_obj = json_tokener_parse(line);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id > max_id) {
                    max_id = existing_id;
                }
            }
        }
        json_object_put(json_obj);
    }

    fclose(file);
    return max_id + 1;
}


void ajouter_livre(int* nb_livres) {
    // Vérifier si le nombre maximum de livres est atteint

    Livre nouveauLivre;

    printf("Entrez les informations du nouveau livre :\n");
    
    printf("Titre : ");
    scanf(" %29[^\n]", nouveauLivre.titre);

    printf("Auteur : ");
    scanf(" %29[^\n]", nouveauLivre.auteur);

    printf("Catégorie : ");
    scanf(" %29[^\n]", nouveauLivre.categorie);

    // Générer un identifiant unique pour le livre
    int nouveau_id = generer_id_unique();
    nouveauLivre.id = nouveau_id;

    nouveauLivre.statut = DISPONIBLE; // Par défaut, le livre est disponible
    nouveauLivre.emprunteur_id = 0; // Par défaut, le livre n'est pas emprunté

    // Créer un objet JSON pour le livre
    json_object *data_livre = json_object_new_object();

    // Ajout des valeurs du livre à l'objet livre JSON
    json_object_object_add(data_livre, "id", json_object_new_int(nouveauLivre.id));
    json_object_object_add(data_livre, "titre", json_object_new_string(nouveauLivre.titre));
    json_object_object_add(data_livre, "auteur", json_object_new_string(nouveauLivre.auteur));
    json_object_object_add(data_livre, "categorie", json_object_new_string(nouveauLivre.categorie));
    json_object_object_add(data_livre, "statut", json_object_new_string(statutToString(nouveauLivre.statut)));
    json_object_object_add(data_livre, "emprunteur", json_object_new_int(nouveauLivre.emprunteur_id));

    // Convertir l'objet JSON en chaîne de caractères
    const char *json_str = json_object_to_json_string_ext(data_livre, JSON_C_TO_STRING_PLAIN);
   
    // Sauvegarder le livre dans un fichier
    FILE *file = fopen("livres.json", "a");
    if (file) {
        fprintf(file, "%s\n", json_str);
        fclose(file);
        printf("Livre ajouté avec succès !\n");
    } else {
        printf("Erreur lors de l'ouverture du fichier.\n");
    }

    // Libérer la mémoire
    json_object_put(data_livre);

}

void supprimer_livre(Livre* livres, int* nb_livres) {
    // Supprimer un livre du catalogue
    // Code d'implémentation
}


void modifier_livre(int livre_id) {
    FILE *file = fopen("../bin/livres.json", "r");
    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    FILE *temp_file = fopen("../bin/temp_livres.json", "w");
    if (temp_file == NULL) {
        printf("Erreur lors de l'ouverture du fichier temporaire.\n");
        fclose(file);
        return;
    }

    char buffer[512];
    int livre_found = 0;

    while (fgets(buffer, sizeof(buffer), file)) {
        json_object *json_obj = json_tokener_parse(buffer);
        if (json_obj != NULL) {
            json_object *id_obj;
            if (json_object_object_get_ex(json_obj, "id", &id_obj)) {
                int existing_id = json_object_get_int(id_obj);
                if (existing_id == livre_id) {
                    livre_found = 1;

                    Livre livre;
                    int choix;
                    printf("Que voulez-vous modifier ?\n");
                    printf("1. Titre\n");
                    printf("2. Auteur\n");
                    printf("3. Catégorie\n");
                    printf("Votre choix : ");
                    scanf("%d", &choix);
                    getchar(); // Pour consommer le caractère de saut de ligne

                    switch (choix) {
                        case 1:
                            printf("Nouveau titre : ");
                            scanf(" %99[^\n]", livre.titre);
                            json_object_object_add(json_obj, "titre", json_object_new_string(livre.titre));
                            break;
                        case 2:
                            printf("Nouvel auteur : ");
                            scanf(" %99[^\n]", livre.auteur);
                            json_object_object_add(json_obj, "auteur", json_object_new_string(livre.auteur));
                            break;
                        case 3:
                            printf("Nouvelle catégorie : ");
                            scanf(" %49[^\n]", livre.categorie);
                            json_object_object_add(json_obj, "categorie", json_object_new_string(livre.categorie));
                            break;
                        default:
                            printf("Choix invalide.\n");
                            json_object_put(json_obj);
                            continue;
                    }
                }
            }

            const char *json_str = json_object_to_json_string_ext(json_obj, JSON_C_TO_STRING_PLAIN);
            fprintf(temp_file, "%s\n", json_str);

            json_object_put(json_obj);
        } else {
            fprintf(temp_file, "%s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    if (livre_found) {
        if (rename("../bin/temp_livres.json", "../bin/livres.json") == 0) {
            printf("Le livre a été modifié avec succès.\n");
        } else {
            printf("Erreur lors de la modification du livre.\n");
        }
    } else {
        remove("../bin/temp_livres.json");
        printf("Le livre avec l'ID %d n'existe pas.\n", livre_id);
    }
}
   
void afficher_livres(Livre* livres, int nb_livres) {
    // Afficher la liste des livres dans le catalogue
    // Code d'implémentation
}

void rechercher_livre(Livre* livres, int nb_livres) {
    // Rechercher un livre par titre, auteur ou catégorie
    // Code d'implémentation
}

void emprunter_livre(Livre* livres, int nb_livres, Membre* membres, int nb_membres) {
    // Emprunter un livre pour un membre
    // Code d'implémentation
}

void retourner_livre(Livre* livres, int nb_livres, Membre* membres, int nb_membres) {
    // Retourner un livre emprunté par un membre
    // Code d'implémentation
}

void liste_livres_empruntes(Membre* membres, int nb_membres) {
    // Afficher la liste des livres empruntés par un membre
    // Code d'implémentation
}

char* statutToString(Statut statut) {
    switch (statut) {
        case DISPONIBLE:
            return "DISPONIBLE";
        case EMPRUNTE:
            return "EMPRUNTE";
        case RESERVE:
            return "RESERVE";
        default:
            return "INCONNU";
    }
}
