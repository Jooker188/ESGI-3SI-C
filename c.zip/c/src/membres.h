#include "livres.h"

#ifndef MEMBRES_H
#define MEMBRES_H

#define MAX_MEMBRES 100
#define MAX_NOM 100
#define MAX_PRENOM 100
#define MAX_DATE 11
#define MAX_EMPRUNTS 11

typedef struct {
    int id;
    char nom[MAX_NOM];
    char prenom[MAX_PRENOM];
    char date_naissance[MAX_DATE];
    Livre* livres_empruntes[MAX_EMPRUNTS];
    int nb_livres_empruntes;
} Membre;

void ajouter_membre();
int generer_id_unique_membre();
void supprimer_membre(int membre_id);
void modifier_membre(int membre_id);
void afficher_membres();
void emprunter_livre(int id_membre, const char* livre);
void menuMembres();
void retour_livre(const char* livre_titre);
void lister_emprunts(int id);
void lister_membres(const char* titre);

#endif
